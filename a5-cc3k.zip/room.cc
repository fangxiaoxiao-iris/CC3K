#include "room.h"

Room::Room() {}

Room::~Room() {}
